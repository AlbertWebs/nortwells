<a  data-toggle="modal" data-target=".bs-example-modal-lg-5" class="pull-up-mobile">
                    <div class="col-md-6 col-sm-6" >
                       <div class="fes7-box wow fadeIn pull-up-mobile" >
                        <h3 style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D8 Digital Nomad Visa</h3>
                          <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                             Aimed at non-EU/EEA/Swiss citizens digital nomads, freelancers, and remote workers.
                          </p>
                       </div>
                    </div>
                 </a>
                 {{--  --}}
                 <div class="modal fade bs-example-modal-lg-5 bootstrap-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                       <div class="modal-body">
                          <div class="modal-content">
                             <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title" id="myLargeModalLabel" style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D8 Digital Nomad Visa</h4>
                             </div>
                             <div class="modal-body">
                                <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                                   {{--  --}}
                                   <i>Requirements:</i><br>
                                   * The applicant must be employed by a company outside of Portugal or self-employed.<br>
                                   * Proof of salary over EUR 3280 grossly per month, equivalent to four times the minimum wage in
                                   Portugal.<br>
                                   * A valid proof of residency in Portugal through at least a 6-12 month lease agreement (depending on
                                   the Embassy/Consulate).
                                   {{--  --}}
                                </p>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
