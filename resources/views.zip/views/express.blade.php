 <a  data-toggle="modal" data-target=".bs-example-modal-lg-6">
                    <div class="col-md-6 col-sm-6" >
                       <div class="fes7-box wow fadeIn" >
                        <h3 style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">Express of Interest Residence Permit</h3>
                          <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                             It is aimed at citizens of the Community of Portuguese-Speaking Countries.
                          </p>
                       </div>
                    </div>
                </a>

                 <div class="modal fade bs-example-modal-lg-6 bootstrap-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                       <div class="modal-body">
                          <div class="modal-content">
                             <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title" id="myLargeModalLabel" style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">EXPRESS OF INTEREST Residence Permit</h4>
                             </div>
                             <div class="modal-body">
                                <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                                   {{--  --}}
                                   <i>Requirements:</i><br>
                                   * Employment contract; or Promise of an employment contract; or Document proving the
                                      establishment of a company, declaring the start of activities with the Tax Administration and Social<br>
                                      Security as an individual; or Service provision contract for the exercise of a liberal profession.
                                   {{--  --}}
                                </p>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
