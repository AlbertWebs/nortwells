<a  data-toggle="modal" data-target=".bs-example-modal-lg-9">
                    <div class="col-md-6 col-sm-6" >
                       <div class="fes7-box wow fadeIn" >
                        <h3 style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D6 Family Reunion Visa</h3>
                          <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                             Aimed at family members of a resident in Portugal also to live, work and study in the country.
                          </p>
                       </div>
                    </div>
                 </a>

                 <div class="modal fade bs-example-modal-lg-9 bootstrap-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                       <div class="modal-body">
                          <div class="modal-content">
                             <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title" id="myLargeModalLabel" style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D6 Family Reunion Visa</h4>
                             </div>
                             <div class="modal-body">
                                <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                                   {{--  --}}
                                   <i>Requirements:</i><br>
                                   * Evidence of family connections and entitlement to family reunification in Portugal.
                                   {{--  --}}
                                </p>
                             </div>
                          </div>
                       </div>
                    </div>
                 </div>
