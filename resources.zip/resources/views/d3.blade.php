<a  data-toggle="modal" data-target=".bs-example-modal-lg-2">
                  <div class="col-md-6 col-sm-6" style="min-height:200">
                     <div class="fes7-box wow fadeIn" >
                        <h3 style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D3 Highly Qualified Individuals Visa</h3>
                        <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal" >
                           Aimed at non-EU citizens with higher education or higher professional technical qualifications - who have a work contract or a promise of work contract for at least 12 months.
                        </p>
                     </div>
                  </div>
               </a>
               {{--  --}}
               <div class="modal fade bs-example-modal-lg-2 bootstrap-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-body">
                        <div class="modal-content">
                           <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                              <h4 class="modal-title" id="myLargeModalLabel" style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">D3 Highly Qualified Individuals Visa</h4>
                           </div>
                           <div class="modal-body">
                              <p style="font-family: 'Lato',Arial,Helvetica,sans-serif; font-style:normal">
                                 {{--  --}}
                                 <i>Requirements:</i><br>
                                 * Proof of higher education qualifications or specialized professional experience.<br><br>
                                 * A valid employment contract or the promise of an employment contract which must be valid for a
                                 minimum period of 12 months.<br><br>
                                 * A monthly pay of at least 1.5X the Portuguese annual minimum gross salary, or 3X the indexed
                                 value of social welfare support (IAS).<br><br>
                                 {{--  --}}
                              </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
